module.exports = {
    // mongoDB 연결할때 넣었던 값을 그대로 복사하여 넣어줌
    // 비밀번호 값도 포함시켜 넣음
      mongoURI: 'mongodb+srv://heodongun08:heodongun0922@allergic.qk69w.mongodb.net/?retryWrites=true&w=majority&appName=allergic' 
  }